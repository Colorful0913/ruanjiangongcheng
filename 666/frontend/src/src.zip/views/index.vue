<template>
  <div class="app-container home">
    <div class="header">
      <h1>华东交通大学宿舍管理系统</h1>
      <p class="welcome-msg">欢迎回家，愿你在校园里度过美好时光</p>
    </div>

    <div class="content-wrapper">
      <div class="left-content">
        <div class="message-card">
          <h2>温馨寄语</h2>
          <div class="message-content">
            <p>亲爱的同学们：</p>
            <p>欢迎回到华东交通大学这个温暖的大家庭。宿舍不仅是你们休息的地方，更是你们在校园里的家。</p>
            <p>在这里，你们将与来自五湖四海的室友相遇，共同学习、生活，一起成长。希望你们能够珍惜这份缘分，相互理解、相互帮助。</p>
            <p>愿你们在新的一学期里：</p>
            <ul>
              <li>学业进步，成绩优异</li>
              <li>身体健康，心情愉快</li>
              <li>与室友和睦相处，共创美好回忆</li>
              <li>积极参与校园活动，丰富大学生活</li>
            </ul>
            <p>无论遇到什么困难，请记住，宿舍管理中心的老师们始终在这里支持你们，为你们提供帮助。</p>
            <p class="blessing">祝愿大家在华东交通大学度过充实而快乐的校园时光！</p>
          </div>
        </div>
      </div>

      <div class="right-content">
        <div class="image-container">
          <img src="@/assets/images/campus.jpg" alt="华东交通大学校园" class="campus-image">
          <div class="image-caption">美景欣赏</div>
        </div>

        <div class="quick-info">
          <h3>温馨提示</h3>
          <ul>
            <li>保持宿舍整洁，营造舒适生活环境</li>
            <li>注意用电安全，禁止使用违规电器</li>
            <li>遵守宿舍管理规定，共建和谐社区</li>
            <li>早睡早起，保持健康作息</li>
            <li>互相关爱，营造温馨室友关系</li>
          </ul>
        </div>
      </div>
    </div>

    <div class="footer">
      <p>华东交通大学宿舍管理中心</p>
      <p>愿每一位学子都能在这里找到属于自己的精彩</p>
    </div>
  </div>
</template>

<script setup name="Index">
function goTarget(url) {
  window.open(url, '__blank')
}
</script>

<style scoped lang="scss">
.home {
  background: linear-gradient(135deg, #f5f7fa 0%, #e4edf9 100%);
  min-height: 100vh;
  padding: 20px;

  .header {
    text-align: center;
    margin-bottom: 30px;
    padding: 30px;
    background: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);

    h1 {
      font-size: 28px;
      margin-bottom: 15px;
      color: #333;
      font-weight: 500;
    }

    .welcome-msg {
      font-size: 18px;
      color: #666;
      font-style: italic;
    }
  }

  .content-wrapper {
    display: flex;
    gap: 30px;
    margin-bottom: 30px;

    .left-content {
      flex: 1;

      .message-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
        height: 100%;

        h2 {
          text-align: center;
          color: #333;
          margin-bottom: 25px;
          font-size: 24px;
          font-weight: 500;
        }

        .message-content {
          font-size: 16px;
          line-height: 1.8;
          color: #555;

          p {
            margin-bottom: 15px;

            &.blessing {
              text-align: center;
              font-weight: bold;
              margin-top: 20px;
              color: #409EFF;
            }
          }

          ul {
            padding-left: 20px;
            margin-bottom: 15px;

            li {
              margin-bottom: 8px;
            }
          }
        }
      }
    }

    .right-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 30px;

      .image-container {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
        text-align: center;

        .campus-image {
          width: 100%;
          max-height: 300px;
          border-radius: 10px;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
          object-fit: cover;
        }

        .image-caption {
          margin-top: 15px;
          color: #777;
          font-style: italic;
        }
      }

      .quick-info {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 15px;
        padding: 25px;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);

        h3 {
          text-align: center;
          color: #333;
          margin-bottom: 20px;
          font-size: 20px;
          font-weight: 500;
        }

        ul {
          padding-left: 20px;

          li {
            margin-bottom: 12px;
            color: #555;
            line-height: 1.5;
          }
        }
      }
    }
  }

  .footer {
    text-align: center;
    padding: 20px;
    color: #777;
    font-size: 14px;

    p {
      margin: 8px 0;
    }
  }
}

@media (max-width: 768px) {
  .content-wrapper {
    flex-direction: column;
  }
}
</style>
