package com.ruoyi.manage.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.manage.mapper.DormAllocationMapper;
import com.ruoyi.manage.domain.DormAllocation;
import com.ruoyi.manage.service.IDormAllocationService;

/**
 * 住宿分配Service业务层处理
 * 
 * @author 余杨俊
 * @date 2025-10-16
 */
@Service
public class DormAllocationServiceImpl implements IDormAllocationService 
{
    @Autowired
    private DormAllocationMapper dormAllocationMapper;

    /**
     * 查询住宿分配
     * 
     * @param allocationId 住宿分配主键
     * @return 住宿分配
     */
    @Override
    public DormAllocation selectDormAllocationByAllocationId(Long allocationId)
    {
        return dormAllocationMapper.selectDormAllocationByAllocationId(allocationId);
    }

    /**
     * 查询住宿分配列表
     * 
     * @param dormAllocation 住宿分配
     * @return 住宿分配
     */
    @Override
    public List<DormAllocation> selectDormAllocationList(DormAllocation dormAllocation)
    {
        return dormAllocationMapper.selectDormAllocationList(dormAllocation);
    }

    /**
     * 新增住宿分配
     * 
     * @param dormAllocation 住宿分配
     * @return 结果
     */
    @Override
    public int insertDormAllocation(DormAllocation dormAllocation)
    {
        dormAllocation.setCreateTime(DateUtils.getNowDate());
        return dormAllocationMapper.insertDormAllocation(dormAllocation);
    }

    /**
     * 修改住宿分配
     * 
     * @param dormAllocation 住宿分配
     * @return 结果
     */
    @Override
    public int updateDormAllocation(DormAllocation dormAllocation)
    {
        dormAllocation.setUpdateTime(DateUtils.getNowDate());
        return dormAllocationMapper.updateDormAllocation(dormAllocation);
    }

    /**
     * 批量删除住宿分配
     * 
     * @param allocationIds 需要删除的住宿分配主键
     * @return 结果
     */
    @Override
    public int deleteDormAllocationByAllocationIds(Long[] allocationIds)
    {
        return dormAllocationMapper.deleteDormAllocationByAllocationIds(allocationIds);
    }

    /**
     * 删除住宿分配信息
     * 
     * @param allocationId 住宿分配主键
     * @return 结果
     */
    @Override
    public int deleteDormAllocationByAllocationId(Long allocationId)
    {
        return dormAllocationMapper.deleteDormAllocationByAllocationId(allocationId);
    }
}
