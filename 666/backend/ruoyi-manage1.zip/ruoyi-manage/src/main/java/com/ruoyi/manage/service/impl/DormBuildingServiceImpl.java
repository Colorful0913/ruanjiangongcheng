package com.ruoyi.manage.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.manage.mapper.DormBuildingMapper;
import com.ruoyi.manage.domain.DormBuilding;
import com.ruoyi.manage.service.IDormBuildingService;

/**
 * 宿舍楼Service业务层处理
 * 
 * @author 余杨俊
 * @date 2025-10-16
 */
@Service
public class DormBuildingServiceImpl implements IDormBuildingService 
{
    @Autowired
    private DormBuildingMapper dormBuildingMapper;

    /**
     * 查询宿舍楼
     * 
     * @param buildingId 宿舍楼主键
     * @return 宿舍楼
     */
    @Override
    public DormBuilding selectDormBuildingByBuildingId(Long buildingId)
    {
        return dormBuildingMapper.selectDormBuildingByBuildingId(buildingId);
    }

    /**
     * 查询宿舍楼列表
     * 
     * @param dormBuilding 宿舍楼
     * @return 宿舍楼
     */
    @Override
    public List<DormBuilding> selectDormBuildingList(DormBuilding dormBuilding)
    {
        return dormBuildingMapper.selectDormBuildingList(dormBuilding);
    }

    /**
     * 新增宿舍楼
     * 
     * @param dormBuilding 宿舍楼
     * @return 结果
     */
    @Override
    public int insertDormBuilding(DormBuilding dormBuilding)
    {
        dormBuilding.setCreateTime(DateUtils.getNowDate());
        return dormBuildingMapper.insertDormBuilding(dormBuilding);
    }

    /**
     * 修改宿舍楼
     * 
     * @param dormBuilding 宿舍楼
     * @return 结果
     */
    @Override
    public int updateDormBuilding(DormBuilding dormBuilding)
    {
        dormBuilding.setUpdateTime(DateUtils.getNowDate());
        return dormBuildingMapper.updateDormBuilding(dormBuilding);
    }

    /**
     * 批量删除宿舍楼
     * 
     * @param buildingIds 需要删除的宿舍楼主键
     * @return 结果
     */
    @Override
    public int deleteDormBuildingByBuildingIds(Long[] buildingIds)
    {
        return dormBuildingMapper.deleteDormBuildingByBuildingIds(buildingIds);
    }

    /**
     * 删除宿舍楼信息
     * 
     * @param buildingId 宿舍楼主键
     * @return 结果
     */
    @Override
    public int deleteDormBuildingByBuildingId(Long buildingId)
    {
        return dormBuildingMapper.deleteDormBuildingByBuildingId(buildingId);
    }
}
