package com.ruoyi.manage.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.manage.mapper.DormRoomMapper;
import com.ruoyi.manage.domain.DormRoom;
import com.ruoyi.manage.service.IDormRoomService;

/**
 * 宿舍房间Service业务层处理
 * 
 * @author 余杨俊
 * @date 2025-10-16
 */
@Service
public class DormRoomServiceImpl implements IDormRoomService 
{
    @Autowired
    private DormRoomMapper dormRoomMapper;

    /**
     * 查询宿舍房间
     * 
     * @param roomId 宿舍房间主键
     * @return 宿舍房间
     */
    @Override
    public DormRoom selectDormRoomByRoomId(Long roomId)
    {
        return dormRoomMapper.selectDormRoomByRoomId(roomId);
    }

    /**
     * 查询宿舍房间列表
     * 
     * @param dormRoom 宿舍房间
     * @return 宿舍房间
     */
    @Override
    public List<DormRoom> selectDormRoomList(DormRoom dormRoom)
    {
        return dormRoomMapper.selectDormRoomList(dormRoom);
    }

    /**
     * 新增宿舍房间
     * 
     * @param dormRoom 宿舍房间
     * @return 结果
     */
    @Override
    public int insertDormRoom(DormRoom dormRoom)
    {
        dormRoom.setCreateTime(DateUtils.getNowDate());
        return dormRoomMapper.insertDormRoom(dormRoom);
    }

    /**
     * 修改宿舍房间
     * 
     * @param dormRoom 宿舍房间
     * @return 结果
     */
    @Override
    public int updateDormRoom(DormRoom dormRoom)
    {
        dormRoom.setUpdateTime(DateUtils.getNowDate());
        return dormRoomMapper.updateDormRoom(dormRoom);
    }

    /**
     * 批量删除宿舍房间
     * 
     * @param roomIds 需要删除的宿舍房间主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByRoomIds(Long[] roomIds)
    {
        return dormRoomMapper.deleteDormRoomByRoomIds(roomIds);
    }

    /**
     * 删除宿舍房间信息
     * 
     * @param roomId 宿舍房间主键
     * @return 结果
     */
    @Override
    public int deleteDormRoomByRoomId(Long roomId)
    {
        return dormRoomMapper.deleteDormRoomByRoomId(roomId);
    }
}
