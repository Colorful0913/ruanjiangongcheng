package com.ruoyi.manage.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.manage.mapper.DormStudentMapper;
import com.ruoyi.manage.domain.DormStudent;
import com.ruoyi.manage.service.IDormStudentService;

/**
 * 学生信息扩展Service业务层处理
 * 
 * @author 余杨俊
 * @date 2025-10-16
 */
@Service
public class DormStudentServiceImpl implements IDormStudentService 
{
    @Autowired
    private DormStudentMapper dormStudentMapper;

    /**
     * 查询学生信息扩展
     * 
     * @param studentId 学生信息扩展主键
     * @return 学生信息扩展
     */
    @Override
    public DormStudent selectDormStudentByStudentId(Long studentId)
    {
        return dormStudentMapper.selectDormStudentByStudentId(studentId);
    }

    /**
     * 查询学生信息扩展列表
     * 
     * @param dormStudent 学生信息扩展
     * @return 学生信息扩展
     */
    @Override
    public List<DormStudent> selectDormStudentList(DormStudent dormStudent)
    {
        return dormStudentMapper.selectDormStudentList(dormStudent);
    }

    /**
     * 新增学生信息扩展
     * 
     * @param dormStudent 学生信息扩展
     * @return 结果
     */
    @Override
    public int insertDormStudent(DormStudent dormStudent)
    {
        dormStudent.setCreateTime(DateUtils.getNowDate());
        return dormStudentMapper.insertDormStudent(dormStudent);
    }

    /**
     * 修改学生信息扩展
     * 
     * @param dormStudent 学生信息扩展
     * @return 结果
     */
    @Override
    public int updateDormStudent(DormStudent dormStudent)
    {
        dormStudent.setUpdateTime(DateUtils.getNowDate());
        return dormStudentMapper.updateDormStudent(dormStudent);
    }

    /**
     * 批量删除学生信息扩展
     * 
     * @param studentIds 需要删除的学生信息扩展主键
     * @return 结果
     */
    @Override
    public int deleteDormStudentByStudentIds(Long[] studentIds)
    {
        return dormStudentMapper.deleteDormStudentByStudentIds(studentIds);
    }

    /**
     * 删除学生信息扩展信息
     * 
     * @param studentId 学生信息扩展主键
     * @return 结果
     */
    @Override
    public int deleteDormStudentByStudentId(Long studentId)
    {
        return dormStudentMapper.deleteDormStudentByStudentId(studentId);
    }
}
