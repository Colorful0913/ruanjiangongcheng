package com.ruoyi.manage.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.manage.domain.DormRoom;
import com.ruoyi.manage.service.IDormRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.manage.mapper.DormAllocationMapper;
import com.ruoyi.manage.domain.DormAllocation;
import com.ruoyi.manage.service.IDormAllocationService;

/**
 * 住宿分配Service业务层处理
 * 
 * @author 余杨俊
 * @date 2025-10-16
 */
@Service
public class DormAllocationServiceImpl implements IDormAllocationService 
{
    @Autowired
    private DormAllocationMapper dormAllocationMapper;
    // 在类的字段部分添加
    @Autowired
    private IDormRoomService dormRoomService;



    /**
     * 查询住宿分配
     * 
     * @param allocationId 住宿分配主键
     * @return 住宿分配
     */
    @Override
    public DormAllocation selectDormAllocationByAllocationId(Long allocationId)
    {
        return dormAllocationMapper.selectDormAllocationByAllocationId(allocationId);
    }

    /**
     * 查询住宿分配列表
     * 
     * @param dormAllocation 住宿分配
     * @return 住宿分配
     */
    @Override
    public List<DormAllocation> selectDormAllocationList(DormAllocation dormAllocation)
    {
        return dormAllocationMapper.selectDormAllocationList(dormAllocation);
    }

    /**
     * 新增住宿分配
     * 
     * @param dormAllocation 住宿分配
     * @return 结果
     */
//    @Override
//    public int insertDormAllocation(DormAllocation dormAllocation)
//    {
//        dormAllocation.setCreateTime(DateUtils.getNowDate());
//        return dormAllocationMapper.insertDormAllocation(dormAllocation);
//    }

//    @Override
//    public int insertDormAllocation(DormAllocation dormAllocation) {
//        dormAllocation.setCreateTime(DateUtils.getNowDate());
//        int result = dormAllocationMapper.insertDormAllocation(dormAllocation);
//
//        // 更新房间的已住人数和状态
//        if (result > 0) {
//            updateRoomStatusAndCount(dormAllocation.getRoomId());
//        }
//
//        return result;
//    }

    @Override
    public int insertDormAllocation(DormAllocation dormAllocation) {
        dormAllocation.setCreateTime(DateUtils.getNowDate());
        int result = dormAllocationMapper.insertDormAllocation(dormAllocation);

        // 确保在插入成功后更新房间状态
        if (result > 0 && dormAllocation.getRoomId() != null) {
            updateRoomStatusAndCount(dormAllocation.getRoomId());
        }

        return result;
    }




    /**
     * 修改住宿分配
     * 
     * @param dormAllocation 住宿分配
     * @return 结果
     */
//    @Override
//    public int updateDormAllocation(DormAllocation dormAllocation)
//    {
//        dormAllocation.setUpdateTime(DateUtils.getNowDate());
//        return dormAllocationMapper.updateDormAllocation(dormAllocation);
//    }

//    @Override
//    public int updateDormAllocation(DormAllocation dormAllocation) {
//        // 先查询原始分配信息
//        DormAllocation oldAllocation = dormAllocationMapper.selectDormAllocationByAllocationId(dormAllocation.getAllocationId());
//
//        dormAllocation.setUpdateTime(DateUtils.getNowDate());
//        int result = dormAllocationMapper.updateDormAllocation(dormAllocation);
//
//        // 更新房间的已住人数和状态
//        if (result > 0) {
//            // 更新原始房间（如果房间ID改变了）
//            if (oldAllocation != null && !oldAllocation.getRoomId().equals(dormAllocation.getRoomId())) {
//                updateRoomStatusAndCount(oldAllocation.getRoomId());
//            }
//            // 更新新房间
//            updateRoomStatusAndCount(dormAllocation.getRoomId());
//        }
//
//        return result;
//    }

    @Override
    public int updateDormAllocation(DormAllocation dormAllocation) {
        // 先查询原始分配信息
        DormAllocation oldAllocation = dormAllocationMapper.selectDormAllocationByAllocationId(dormAllocation.getAllocationId());

        dormAllocation.setUpdateTime(DateUtils.getNowDate());
        int result = dormAllocationMapper.updateDormAllocation(dormAllocation);

        // 更新房间的已住人数和状态
        if (result > 0) {
            // 更新原始房间（如果房间ID改变了）
            if (oldAllocation != null && !oldAllocation.getRoomId().equals(dormAllocation.getRoomId())) {
                updateRoomStatusAndCount(oldAllocation.getRoomId());
            }
            // 更新新房间
            if (dormAllocation.getRoomId() != null) {
                updateRoomStatusAndCount(dormAllocation.getRoomId());
            }
        }

        return result;
    }




    /**
     * 批量删除住宿分配
     * 
     * @param allocationId 需要删除的住宿分配主键
     * @return 结果
     */
//    @Override
//    public int deleteDormAllocationByAllocationIds(Long[] allocationIds)
//    {
//        return dormAllocationMapper.deleteDormAllocationByAllocationIds(allocationIds);
//    }

//    @Override
//    public int deleteDormAllocationByAllocationId(Long allocationId) {
//        // 先查询分配信息以获取房间ID
//        DormAllocation allocation = dormAllocationMapper.selectDormAllocationByAllocationId(allocationId);
//
//        int result = dormAllocationMapper.deleteDormAllocationByAllocationId(allocationId);
//
//        // 更新房间的已住人数和状态
//        if (result > 0 && allocation != null) {
//            updateRoomStatusAndCount(allocation.getRoomId());
//        }
//
//        return result;
//    }

    @Override
    public int deleteDormAllocationByAllocationId(Long allocationId) {
        // 先查询分配信息以获取房间ID
        DormAllocation allocation = dormAllocationMapper.selectDormAllocationByAllocationId(allocationId);

        int result = dormAllocationMapper.deleteDormAllocationByAllocationId(allocationId);

        // 更新房间的已住人数和状态
        if (result > 0 && allocation != null && allocation.getRoomId() != null) {
            updateRoomStatusAndCount(allocation.getRoomId());
        }

        return result;
    }




    /**
     * 删除住宿分配信息
     * 
     * @param allocationIds 住宿分配主键
     * @return 结果
     */
//    @Override
//    public int deleteDormAllocationByAllocationId(Long allocationId)
//    {
//        return dormAllocationMapper.deleteDormAllocationByAllocationId(allocationId);
//    }

    @Override
    public int deleteDormAllocationByAllocationIds(Long[] allocationIds) {
        // 先查询所有分配信息以获取房间ID
        Set<Long> roomIds = new HashSet<>();
        for (Long allocationId : allocationIds) {
            DormAllocation allocation = dormAllocationMapper.selectDormAllocationByAllocationId(allocationId);
            if (allocation != null) {
                roomIds.add(allocation.getRoomId());
            }
        }

        int result = dormAllocationMapper.deleteDormAllocationByAllocationIds(allocationIds);

        // 更新涉及的房间的已住人数和状态
        if (result > 0) {
            for (Long roomId : roomIds) {
                updateRoomStatusAndCount(roomId);
            }
        }

        return result;
    }


//    /**
//     * 更新房间的已住人数和状态
//     * @param roomId 房间ID
//     */
//    private void updateRoomStatusAndCount(Long roomId) {
//        // 查询房间信息
//        DormRoom room = dormRoomService.selectDormRoomByRoomId(roomId);
//        if (room == null) {
//            return;
//        }
//
//        // 查询该房间的住宿分配数量
//        DormAllocation queryAllocation = new DormAllocation();
//        queryAllocation.setRoomId(roomId);
//        queryAllocation.setStatus("0"); // 只统计入住中的学生
//        List<DormAllocation> allocations = dormAllocationMapper.selectDormAllocationList(queryAllocation);
//
//        // 更新已住人数
//        int currentCount = allocations.size();
//        room.setCurrentCount((long) currentCount);
//
//        // 根据已住人数和床位数量更新状态
//        if ("2".equals(room.getStatus())) {
//            // 如果房间状态是维修中，则不改变状态
//            // 维修中的房间即使没有人住也保持维修中状态
//        } else if (currentCount >= room.getMaxCount()) {
//            // 如果已住人数大于等于床位数量，则状态设为已满员
//            room.setStatus("1");
//        } else {
//            // 否则状态设为可入住
//            room.setStatus("0");
//        }
//
//        // 更新房间信息
//        dormRoomService.updateDormRoom(room);
//    }

    /**
     * 更新房间的已住人数和状态
     * @param roomId 房间ID
     */
    private void updateRoomStatusAndCount(Long roomId) {
        // 查询房间信息
        DormRoom room = dormRoomService.selectDormRoomByRoomId(roomId);
        if (room == null) {
            return;
        }

        // 查询该房间的住宿分配数量（只统计有效的分配）
        DormAllocation queryAllocation = new DormAllocation();
        queryAllocation.setRoomId(roomId);
        queryAllocation.setStatus("0"); // 只统计入住中的学生
        List<DormAllocation> allocations = dormAllocationMapper.selectDormAllocationList(queryAllocation);

        // 更新已住人数
        int currentCount = allocations != null ? allocations.size() : 0;
        room.setCurrentCount((long) currentCount);

        // 根据已住人数和床位数量更新状态
        // 注意：如果房间已被标记为维修中(2)，则保持该状态
        if (!"2".equals(room.getStatus())) { // 只有非维修状态才重新计算
            if (currentCount >= room.getMaxCount()) {
                // 如果已住人数大于等于床位数量，则状态设为已满员
                room.setStatus("1");
            } else {
                // 否则状态设为可入住
                room.setStatus("0");
            }
        }

        // 更新房间信息
        dormRoomService.updateDormRoom(room);
    }








}
